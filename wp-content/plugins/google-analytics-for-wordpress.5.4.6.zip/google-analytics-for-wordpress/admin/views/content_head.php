<div id="yoast-ga-wrapper">
	<div class="yoast-ga-content">